#!/bin/bash
service nginx restart
